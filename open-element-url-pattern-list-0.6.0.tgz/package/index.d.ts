/**
 * url-pattern-list - efficiently match URLs against a collection of URL
 * patterns.
 *
 * This implementation is derived from the semantics OpenElement established
 * for its maintained fork: only canonical pathname literals are indexed, every
 * other pattern is matched conservatively, and candidates are merged by
 * registration order before a full `exec()` decides the match. See
 * PROVENANCE.md and DIVERGENCE.md.
 */
/**
 * The minimal pattern interface stored by a URLPatternList.
 *
 * Any object with a `pathname` getter and the `exec()` method of the
 * URLPattern interface works: native `URLPattern` instances and
 * polyfill (`urlpattern-polyfill`) instances alike. Pattern parsing,
 * compilation and capture semantics belong entirely to the pattern's
 * constructor; this library only stores, indexes and matches patterns in
 * registration order.
 */
export interface ListPattern {
    readonly pathname: string;
    exec(input: string, baseURL?: string): URLPatternResult | null;
}
/**
 * The return type of `URLPatternList.match()`.
 *
 * Includes the result of `pattern.exec()` and the matching pattern's associated
 * metadata value.
 */
export interface URLPatternListMatch<T> {
    result: URLPatternResult;
    value: T;
}
/**
 * A collection of URL patterns and associated values, with methods for adding
 * patterns and matching URLs against those patterns.
 *
 * Patterns with a canonical pathname literal are stored in a fixed prefix tree
 * keyed by that literal; all other patterns are stored in a conservative list.
 * Matching execs the candidates of both collections in registration order and
 * returns the first complete match. This maintains first-match-wins
 * semantics - the result is the same as scanning a linear list of patterns -
 * while only execing the patterns that can possibly match.
 *
 * Pruning is based solely on canonical pathname literal equality, which is a
 * necessary condition for `exec()` to match. Pruning never involves other URL
 * components, so empty URL components never disappear from matching and the
 * final `exec()` sees every pattern that could match.
 */
export declare class URLPatternList<T> {
    #private;
    /**
     * Add a URL pattern to the collection.
     */
    addPattern(pattern: ListPattern, value: T): void;
    /**
     * Match a URL against the URLPatterns, returning the first match found and
     * its associated value.
     *
     * The input is normalized once with the `URL` constructor and both pruning
     * and `exec()` consume the same normalized URL. Invalid input throws a
     * `TypeError`, including for an empty list; relative string input requires a
     * `baseUrl`.
     *
     * @param url - The URL to match
     * @param baseUrl - Optional base URL for relative path resolution
     */
    match(url: string | URL, baseUrl?: string): URLPatternListMatch<T> | null;
    /**
     * Diagnostic upper bound on the number of patterns that `match()` would
     * exec for the given input. Not part of the matching semantics; no matcher
     * internals are exposed.
     */
    candidateCount(url: string | URL, baseUrl?: string): number;
}
//# sourceMappingURL=index.d.ts.map